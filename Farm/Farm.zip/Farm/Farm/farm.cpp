#include "farm.h"

Info::Info()
{

}

void Info::Set(string i, string u, string c, int q, double p)
{

}

double Info::GetTotal() const
{

}


string Info::GetItem() const
{

}

string Info::GetCategory() const
{

}

void Info::Show() const
{
	cout << left;
	cout << setw(10) << item << setw(10) << price
		<< setw(10) << unit << setw(10) << category 
		<< setw(10) << quantity << setw(10) << GetTotal()
		<< endl;
	cout << right;
}

Farm::Farm()
{

}

Farm::~Farm()
{

}

bool Farm::LoadInfo()
{

}

double Farm::AllTotal() const
{

}

void Farm::PrintHeader() const
{
	cout << left;
	cout << setw(10) << "Item" << setw(10) << "Price"
		<< setw(10) << "Unit" << setw(10) << "Category" 
		<< setw(10) << "Quantity" << setw(10) << "Total"
		<< endl;
	cout << right;	
}

void Farm::Summary() const
{

}

bool Farm::Search(const string target, const char field) const
{

}