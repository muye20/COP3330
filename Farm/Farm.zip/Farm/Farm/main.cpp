#include "farm.h"

void PrintIntro();

int main()
{
	Farm f1;

	if(f1.LoadInfo())
	{
		char input, f;
		string t;
		do
		{
			PrintIntro();
			cin >> input;
			switch(input)
			{
			case '1':
				f1.Summary();
				break;
			case '2':
				cout << "Total value is " << f1.AllTotal() << endl;
				break;
			case '3':
				cout << "Enter the target value" << endl;
				cin >> t;
				cout << "Enter the field to search (i for item, c for category)" << endl;
				cin >> f;

				if(!f1.Search(t, f))
					cout << "Cannot find " << t << endl;

				break;
			case 'q':
				cout << "Terminating" << endl;
				break;
			default:
				cout << "UNKOWN INPUT " << endl;
				break;
			}
			cout << endl;
		}while(input != 'q');
	}
	else
		cout << "Fail to load info " << endl;

	cout << "Before return 0" << endl;
	return 0;
}

void PrintIntro()
{
	cout << "Enter 1 for Summary()" << endl;
	cout << "Enter 2 for AllTotal()" << endl;
	cout << "Enter 3 for Search()" << endl;
	cout << "Enter q for quit" << endl; 
}