#include <iostream>
#include <iomanip>
#include <cstring>
#include <string>
#include <cstdlib>
#include <ctime>

using namespace std;

#define PRINT 1
const int NUM_LEN = 10;
const int MAX_NUM = 25600;

struct MyInt
{
	int len;
	char *num;
};

void GetMyInt(MyInt &int_num, const char *char_int);
void PrintMyInt(const MyInt int_num);
void Multiply(const MyInt int_num1, const MyInt int_num2, MyInt &ans); 
void PrintArray(const char *str, const int LEN);
void GetNumStr(char digit_arr[NUM_LEN], const int num);

int main()
{
	int n1, n2, n3;
	char num1[NUM_LEN];
	char num2[NUM_LEN];
	MyInt myint1, myint2, myans;

	srand(static_cast<unsigned int>(time(NULL)));

	//n1 = rand() % MAX_NUM;
	//n2 = rand() % MAX_NUM;
	n1 = 835;
	n2 = 49;
	n3 = n1 * n2;

	GetNumStr(num1, n1); // convert integer to char array 
	GetNumStr(num2, n2);

	GetMyInt(myint1, num1);  // put char array to MyInt
	GetMyInt(myint2, num2);

	if(PRINT)
	{
		for(int i = 0; i < myint1.len; i++)
			num1[i] = num1[i] - '0';
		for(int i = 0; i < myint2.len; i++)
			num2[i] = num2[i] - '0';
		PrintArray(num1, myint1.len);
		PrintArray(num2, myint2.len);
	}

	PrintMyInt(myint1);   
	PrintMyInt(myint2);
	cout << left;
	cout << setw(15) << "int Version " << n1 << " * " << n2 << " = " << n3 << endl;
	cout << setw(15) << "MyInt Version " << n1 << " * " << n2 << " = ";
	cout << right;

	return 0;
}

void Multiply(const MyInt int_num1, const MyInt int_num2, MyInt &ans)
{

}

void GetMyInt(MyInt &int_num, const char *char_int)
{
	int_num.len = (int) strlen(char_int);
	int_num.num = new char [int_num.len + 1];
	int_num.num[int_num.len] = '\0';

	strncpy(int_num.num, char_int, int_num.len);
}

void PrintMyInt(const MyInt int_num)
{
	// print MyInt number backward
	for(int i = int_num.len - 1; i >= 0; i--)	
		cout << int_num.num[i];
	cout << endl;
}

void PrintArray(const char *str, const int LEN)
{
	string ind; 
	const int width = 5;
	ind.clear();

	cout << left;
	for(int i = 0; i < LEN; i++)
	{
		ind = ind + "[" + (char)(i + '0') + "]";
		cout << setw(width) << ind;
		ind.clear();
	}

	cout << endl;

	for(int i = 0; i < LEN; i++)
	{
		cout << " " << setw(width - 1) << (int) str[i];
	}
	cout << right;
	cout << endl;

}

void GetNumStr(char digit_arr[NUM_LEN], const int num)
{
	int tmp = num;
	int i = 0;

	do
	{
		digit_arr[i] = tmp % 10 + '0';
		tmp = tmp / 10;
		i++;
	}while(tmp != 0);

	digit_arr[i] = '\0';
}
