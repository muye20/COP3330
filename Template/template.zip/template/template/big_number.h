#include <iostream>
#include <cstring>

using namespace std;

#define DEBUG_PRINT 0

const int MIN_LEN = 5;
const int INT_MAX_LEN = 10;
const char GET_QUOTIENT = 'q';
const char GET_REMAINDER = 'r';

bool isValid(const char c);
int Min(const int n1, const int n2);
int Max(const int n1, const int n2);
void PrintArray(const char *ARR, const int LEN);

class MyInt
{
	friend istream& operator>>(istream& is, MyInt& bn);
	friend ostream& operator<<(ostream& os, const MyInt& bn);
	friend MyInt operator+(const MyInt &n1, const MyInt &n2);
	friend MyInt operator-(const MyInt &n1, const MyInt &n2);
	friend MyInt operator*(const MyInt &n1, const MyInt &n2);
	friend MyInt operator/(const MyInt &n1, const MyInt &n2);
	friend MyInt operator%(const MyInt &n1, const MyInt &n2);
	friend bool operator<(const MyInt &n1, const MyInt &n2);
	friend bool operator>(const MyInt &n1, const MyInt &n2);
	friend bool operator>=(const MyInt &n1, const MyInt &n2);
	friend bool operator<=(const MyInt &n1, const MyInt &n2);
	friend bool operator==(const MyInt &n1, const MyInt &n2);
	friend bool operator!=(const MyInt &n1, const MyInt &n2);

public:
	MyInt(); // default constructor
	MyInt(const char *str_in); // conversion constructor for char array
	MyInt(const int num_in); // conversion constructor for int
	MyInt(const MyInt& target); // copy constructor
	~MyInt(); // destructor

	MyInt& operator=(const MyInt& RHS); // assignment operator overloading
	MyInt& operator++(); // prefix
	MyInt operator++(int); // postfix
	void Display() const;
	int GetCurrLen() const; 
	int GetMaxLen() const;
	bool isZero() const;

private:
	char *num;
	int curr_len;
	int max_len;
	MyInt Adder(const MyInt &n1, const MyInt &n2) const;
	MyInt Multiplier(const MyInt &n1, const MyInt &n2) const;
	MyInt Subtractor(const MyInt &n1, const MyInt &n2) const;
	MyInt Divider(const MyInt &n1, const MyInt &n2, const char MODE) const;
	void AppendDigit(const char c);
	void Reset();
};


