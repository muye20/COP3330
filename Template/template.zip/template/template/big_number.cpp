#include "big_number.h"

bool isValid(const char c)
{
	bool ret;
	ret = false;

	if(c >= '0' && c <= '9')
		ret = true;

	return ret;
}

int Min(const int n1, const int n2)
{
	return (n1 < n2 ? n1 : n2);
}

int Max(const int n1, const int n2)
{
	return (n1 > n2 ? n1 : n2);
}

void PrintArray(const char *ARR, const int LEN)
{
	char *tmp = new char [LEN];
	strncpy(tmp, ARR, LEN);
	tmp[LEN] = '\0';
	cout << tmp << endl;
	delete [] tmp;
}

MyInt::MyInt()
{
	num = new char [MIN_LEN];
	//cout << "Allocate Memory" << endl;

	max_len = MIN_LEN;
	num[0] = '0';
	num[1] = '\0';  // NULL terminate
	curr_len = 1;
	//cout << "Constructor DONE" << endl;
}

MyInt::MyInt(const int num_in)
{
	if(num_in > 0)
	{
		int num_digit = 0;
		int temp;
		max_len = INT_MAX_LEN;
		char *tmp_num = new char [max_len];
		num = new char [max_len];

		temp = num_in;
		do
		{
			tmp_num[num_digit] = (temp % 10) + '0';
			temp = temp / 10;
			num_digit++;
		}while(temp);
		curr_len = num_digit;

		while(num_digit)
		{
			num_digit--;
			num[temp] = tmp_num[num_digit];
			temp++;		
		}

		num[temp] = '\0';

		delete [] tmp_num;
	}
	else
	{
		num = new char [MIN_LEN];
		max_len = MIN_LEN;
		num[0] = '0';
		num[1] = '\0';  // NULL terminate
		curr_len = 1;	
	}
}

MyInt::MyInt(const char *str_in)
{
	int num_element = strlen(str_in);
	bool valid_digit = true;
	int i = 0;
	int lead_zero_count = 0;

	// handle input like 0000000001
	while(str_in[lead_zero_count] == '0' && 
		lead_zero_count < num_element)
		lead_zero_count++;

	if(lead_zero_count < num_element)
	{
		i = lead_zero_count;
		do
		{
			if(!isValid(str_in[i]))
				valid_digit = false;
			i++;
		}while(i < num_element && valid_digit);	
	}
	else
		valid_digit = false;

	if(!valid_digit)
	{
		max_len = MIN_LEN;
		num = new char [max_len];
		num[0] = '0';
		num[1] = '\0';  // NULL terminate
		curr_len = 1;
	}
	else
	{
		num_element = num_element - lead_zero_count;
		max_len = num_element * 2;
		num = new char [max_len];
		strncpy(num, str_in + lead_zero_count, num_element);
		num[num_element] = '\0';
		curr_len = num_element;
	}
}

MyInt::MyInt(const MyInt& target)
{
	//if(DEBUG_PRINT)
	//	cout << "Copy Constructor Called" << endl;
	curr_len = target.curr_len;
	max_len = target.max_len;

	num = new char [max_len];
	strncpy(num, target.num, curr_len);
	num[curr_len] = '\0';
}

MyInt::~MyInt()
{
	delete [] num;
}

bool MyInt::isZero() const
{
	bool ret = false;
	if(num[0] == '0')
		ret = true;
	return ret;
}

void MyInt::Display() const
{
	cout << num << endl;
	cout << "Length is " << curr_len << endl;
	cout << "Max Length is " << max_len << endl;
}

int MyInt::GetCurrLen() const
{
	return curr_len;
}

int MyInt::GetMaxLen() const
{
	return max_len;
}

MyInt& MyInt::operator=(const MyInt	&RHS)
{
	if(this != &RHS)
	{
		curr_len = RHS.curr_len;
		max_len = RHS.max_len;

		delete [] num; // release previously occupied memory space

		num = new char [max_len];
		strncpy(num, RHS.num, curr_len);
		num[curr_len] = '\0';
	}

	return *this;
}

ostream & operator<<(ostream& os, const MyInt& bn)
{
	os << bn.num;

	return os;
}

istream &operator>>(istream  &input, MyInt &bn)
{
	char tmp = '0';
	bool num_end;

	input >> tmp; // get the first digit, skip any white space before it

	// handles 0000000...
	while(tmp == '0')
		tmp = input.get();

	// if it is valid digit
	if(isValid(tmp))
	{
		bn.Reset();
		bn.AppendDigit(tmp);
		num_end = false;

		do
		{
			tmp = input.peek();
			if(isValid(tmp))
			{
				tmp = input.get();
				bn.AppendDigit(tmp);
			}
			else
				num_end = true;

		}while(!num_end);
	}

	return input;
}

void MyInt::AppendDigit(const char c)
{
	if(num[0] == '0')
		num[0] = c;
	else
	{
		num[curr_len] = c;
		curr_len++;
	}
	// expand array
	if(curr_len == max_len)
	{
		max_len = max_len * 2;
		char *tmp_num = new char [max_len];

		strncpy(tmp_num, num, curr_len);

		delete [] num;
		num = tmp_num;
	}
	num[curr_len] = '\0';
}


bool operator< (const MyInt &n1, const MyInt &n2)
{
	bool is_less;
	is_less = false;

	if(DEBUG_PRINT)
	{
		cout << "Num1 Len " << n1.curr_len << endl;
		cout << "Num2 Len " << n2.curr_len << endl;
	}

	if(n1.curr_len < n2.curr_len)
		is_less = true;
	else if(n1.curr_len > n2.curr_len)
		is_less = false;
	else if(strncmp(n1.num, n2.num, n1.curr_len) == 0)
		is_less = false;
	else
	{
		int i = 0;
		while(n1.num[i] == n2.num[i])
			i++;

		if(n1.num[i] > n2.num[i])
			is_less = false;
		else
			is_less = true;
	}

	return is_less;
}

bool operator== (const MyInt &n1, const MyInt &n2)
{
	bool is_equal;
	is_equal = false;

	if(n1.curr_len != n2.curr_len)
		is_equal = false;
	else
	{
		if(strncmp(n1.num, n2.num, n1.curr_len) == 0)
			is_equal = true;
	}

	return is_equal;
}

bool operator>= (const MyInt &n1, const MyInt &n2)
{
	return !(n1 < n2);
}

bool operator!= (const MyInt &n1, const MyInt &n2)
{
	return !(n1 == n2);
}

bool operator<= (const MyInt &n1, const MyInt &n2)
{
	return (n1 < n2) || (n1 == n2);
}

bool operator> (const MyInt &n1, const MyInt &n2)
{
	return !(n1 < n2) && (n1 != n2);
}

void MyInt::Reset()
{
	delete [] num; // deallocate previously occupied memory

	num = new char [MIN_LEN];
	max_len = MIN_LEN;
	num[0] = '0';
	num[1] = '\0';  // NULL terminate
	curr_len = 1;	
}

