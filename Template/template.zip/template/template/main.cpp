#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include "big_number.h"

using namespace std;

#define PRINT_TABLE 0

const int LEN = 6;
const string FN = "Big_Number_Test.txt";
enum OP_TYPE {E = 0, LE, GE, L, G, NE};
const char OPERATOR[][NE] = {"==", "<=", ">=", "<", ">", "!="}; 


bool Check(bool mat1[][LEN], bool mat2[][LEN]);

int main()
{
	string slist[LEN];			// string array
	int ilist[LEN];				// int array
	MyInt blist[LEN];			// MyInt array 

	bool i_mat[LEN][LEN];		
	bool b_mat[LEN][LEN];


	return 0;
}

bool Check(bool mat1[][LEN], bool mat2[][LEN])
{
	int i = 0;
	int j = 0;
	bool pass = true;

	while(i < LEN && pass)
	{
		while(j < LEN && pass)
		{
			if(mat1[i][j] != mat2[i][j])
				pass = false;
			j++;
		}
		i++;
	}

	return pass;
}
