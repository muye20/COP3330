#include <fstream>
#include <string>
#include "BigNumber.h"

const int NUM_CASE = 5;
const string TEST = "test_";

void PrintFile(const string FILE_NAME);
void Read_BigNum(const string FILE_NAME);

int main()
{
	string test_files[NUM_CASE];
	int case_num;

	for(int i = 0; i < NUM_CASE; i++)
	{
		test_files[i] = TEST + ((char) ('0' + i + 1)) + ".txt";
		cout << "Test Case " << i + 1 
			<< " : " << test_files[i] << endl;
	}

	cout << "Enter Test Case\t";
	cin >> case_num;

	if(case_num > 0 && case_num < NUM_CASE + 1)
	{
		PrintFile(test_files[case_num - 1]);
		Read_BigNum(test_files[case_num - 1]);
	}

	return 0;
}

void PrintFile(const string FILE_NAME)
{
	ifstream fin;
	string line;
	fin.open(FILE_NAME.c_str(), ios::in);

	if(fin)
	{
		cout << "File Content (Start)" << endl;
		while(!fin.eof())
		{
			getline(fin, line);
			cout << line << endl;
		}
		cout << "File Content (End)" << endl;
		fin.clear();
		fin.close();
	}
	else
		cout << "Cannot Open " << FILE_NAME << endl;
}

void Read_BigNum(const string FILE_NAME)
{
	BigNumber nums[2];
	ifstream fin;
	fin.open(FILE_NAME.c_str(), ios::in);

	if(fin)
	{
		int i = 0;
		while(!fin.eof())
		{
			fin >> nums[i]; // extraction overloading for BigNumber 
			cout << "nums[" << i << "] = " << nums[i] << endl;
			//i++;
		}

		fin.clear();
		fin.close();
	}
	else
		cout << "Cannot Open " << FILE_NAME << endl;
}