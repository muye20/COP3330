#include <iostream>
#include <cstring>

using namespace std;

const int DEFAULT_LEN = 5;
const char DEFAULT_NUM = '0';

bool isValid(const int c); 

class BigNumber
{
	friend istream& operator>>(istream& is, BigNumber& bn);
	friend ostream& operator<<(ostream& os, const BigNumber& bn);

public:
	BigNumber();
	~BigNumber();

private:
	char *num;			// default is '0'
	int curr_len;		// default is 1
	int max_len;		// default is 5
	void AppendDigit(const char d);
	void Reset();
};