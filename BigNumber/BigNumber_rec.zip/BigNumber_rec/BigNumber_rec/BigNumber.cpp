#include "BigNumber.h"

bool isValid(const int c)
{
	bool ret;
	ret = true;

	if(c < '0' || c > '9')
		ret = false;
	
	return ret;
}

