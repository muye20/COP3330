#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <ctime>
using namespace std;

const int NUM_SEN = 200;
const string FN = "Review.txt";

void PrintFile(const string f);

// base class
class Animal
{
public:
	void SetWeight(double w);
	void SetFoodtype(string ft);
	void Set(double w, string ft);
	
	double GetWeight() const;
	string GetFoodtype() const;

private:
	double weight;
	string food_type;
};

// another base class
class Dialog
{
public:
	Dialog();
	string GetSentence() const;
private:
	string Sentence[NUM_SEN];
	int max_sentence;
};

// derived class
class Monkey: public Animal, public Dialog
{
public:
	Monkey();
	void Climb();
	void Display() const;

private:
	int climb_count;
};

// derived class
class Rabbit: public Animal, public Dialog
{
public:
	Rabbit();
	void Dig();
	void Display() const;

private:
	int dig_count;
};