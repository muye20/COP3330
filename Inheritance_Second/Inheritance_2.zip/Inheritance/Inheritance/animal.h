#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <ctime>
using namespace std;

void PrintFile(const string f);

// base class
class Animal
{
public:
	void SetWeight(double w);
	void SetFoodtype(string ft);
	void Set(double w, string ft);
	
	double GetWeight() const;
	string GetFoodtype() const;

private:
	double weight;
	string food_type;
};

// derived class
class Monkey: public Animal
{
public:
	Monkey();
	void Climb();
	void Display() const;

private:
	int climb_count;
};

// derived class
class Rabbit: public Animal
{
public:
	Rabbit();
	void Dig();
	void Display() const;

private:
	int dig_count;
};