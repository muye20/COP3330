#include "animal.h"

const int NR = 5;
const int NM = 5;

int main()
{
	//srand(static_cast<unsigned int>(time(NULL)));
	int i, total;
	Animal *alist[NR + NM]; // static allocation
	Monkey mlist[NM];
	Rabbit rlist[NR];

	total = NR + NM;

	for(i = 0; i < NM; i++)
		mlist[i].Display();

	for(i = 0; i < NR; i++)
		rlist[i].Display();

	return 0;
}