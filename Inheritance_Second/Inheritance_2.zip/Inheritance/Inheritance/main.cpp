#include "animal.h"

const int NR = 5;
const int NM = 5;

int main()
{
	srand(static_cast<unsigned int>(time(NULL)));
	int i, total;
	Monkey mlist[NM];		// for monkey
	Rabbit rlist[NR];		// for rabbit
	Animal *alist[NR + NM]; // mixing monkey and rabbit static allocation

	total = NR + NM;

	for(i = 0; i < NM; i++)
		mlist[i].Display();

	for(i = 0; i < NR; i++)
		rlist[i].Display();

	return 0;
}