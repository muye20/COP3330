#include "animal.h"


void PrintFile(const string f)
{
	ifstream fin;
	fin.open(f.c_str(), ios::in);

	if(fin)
	{
		string line;
		while(!fin.eof())
		{
			getline(fin, line);
			cout << line << endl;
		}
		fin.clear();
		fin.close();
	}
	else
		cout << "Cannot Open File " << endl;
}


void Animal::SetFoodtype(string ft)
{
	food_type = ft;
}

void Animal::SetWeight(double w)
{
	weight = w;
}

void Animal::Set(double w, string ft)
{
	SetFoodtype(ft);
	SetWeight(w);
}

double Animal::GetWeight() const 
{
	return weight;
}

string Animal::GetFoodtype() const 
{
	return food_type;
}

Monkey::Monkey()
{
	double w = rand() % 50 / 10.0; 
	string ft = "Banana";

	Set(w, ft);
	climb_count = 0;
}

void Monkey::Climb()
{
	climb_count++;
	cout << "Monkey climbed " << climb_count << " trees" << endl;
}

void Monkey::Display() const
{
	int i = rand() % 5 + 1;
	string str = "m";
	str = str + (char)('0' + i);
	PrintFile(str);
}

Rabbit::Rabbit()
{
	int c = rand() % 300;
	double w = rand() % 15 / 10.0;
	string ft = "Carrot";

	Set(w, ft);
	dig_count = 0;
}

void Rabbit::Dig()
{
	dig_count++;
	cout << "Rabbit dug " << dig_count << " holes" << endl; 
}

void Rabbit::Display() const
{
	int i = rand() % 5 + 1;
	string str = "r";
	str = str + (char)('0' + i);
	PrintFile(str);
}

