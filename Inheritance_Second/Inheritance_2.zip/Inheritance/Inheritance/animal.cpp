#include "animal.h"


void PrintFile(const string f)
{
	ifstream fin;
	fin.open(f.c_str(), ios::in);

	if(fin)
	{
		string line;
		while(!fin.eof())
		{
			getline(fin, line);
			cout << line << endl;
		}
		fin.clear();
		fin.close();
	}
	else
		cout << "Cannot Open File " << endl;
}

Dialog::Dialog()
{
	ifstream fin;

	fin.open(FN.c_str(), ios::in);
	if(fin)
	{
		int i = 0;
		while(i < NUM_SEN && !fin.eof())
		{
			// store the ith line in the file
			getline(fin, Sentence[i]);  
			i++;
		}
		max_sentence = i;
		fin.clear();
		fin.close();
	}
	else
		cout << "No Such File " << endl;
}

string Dialog::GetSentence() const
{
	// return a string randomly
	return Sentence[rand() % max_sentence];  
}


void Animal::SetFoodtype(string ft)
{
	food_type = ft;
}

void Animal::SetWeight(double w)
{
	weight = w;
}

void Animal::Set(double w, string ft)
{
	SetFoodtype(ft);
	SetWeight(w);
}

double Animal::GetWeight() const 
{
	return weight;
}

string Animal::GetFoodtype() const 
{
	return food_type;
}

Monkey::Monkey()
{
	double w = rand() % 50 / 10.0; 
	string ft = "Banana";

	Set(w, ft);
	climb_count = 0;
}

void Monkey::Climb()
{
	climb_count++;
	cout << "Monkey climbed " << climb_count << " trees" << endl;
}

void Monkey::Display() const
{
	int i = rand() % 5 + 1;
	string str = "m";
	str = str + (char)('0' + i);
	PrintFile(str);

	cout << GetSentence() << endl; // GetSentence() is from Dialog class 
	cout << endl;
}

Rabbit::Rabbit()
{
	int c = rand() % 300;
	double w = rand() % 15 / 10.0;
	string ft = "Carrot";

	Set(w, ft);
	dig_count = 0;
}

void Rabbit::Dig()
{
	dig_count++;
	cout << "Rabbit dug " << dig_count << " holes" << endl; 
}

void Rabbit::Display() const
{
	int i = rand() % 5 + 1;
	string str = "r";
	str = str + (char)('0' + i);
	PrintFile(str);

	cout << GetSentence() << endl;   // GetSentence() is from Dialog class 
	cout << endl;
}

