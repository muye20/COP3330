#include "animal.h"

void Animal::SetCount(int c)
{
	count = c;
}

void Animal::SetFoodtype(string ft)
{
	food_type = ft;
}

void Animal::SetWeight(double w)
{
	weight = w;
}

void Animal::Set(double w, string ft, int c)
{
	SetCount(c);
	SetFoodtype(ft);
	SetWeight(w);
}

void Animal::Display() const
{
	cout << "Weight is " << weight << endl;
	cout << "Food Type " << food_type << endl;
}

int Animal::GetCount() const
{
	return count;
}


