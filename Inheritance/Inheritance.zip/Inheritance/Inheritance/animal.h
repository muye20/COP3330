#include <iostream>
#include <string>
#include <cstdlib>

using namespace std;

// base class
class Animal
{
public:
	void SetWeight(double w);
	void SetFoodtype(string ft);
	void SetCount(int c);
	void Set(double w, string ft, int c);
	void Display() const;
	int GetCount() const;

private:
	double weight;
	string food_type;
	int count;
};

