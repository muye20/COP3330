#include "animal.h"


int main()
{
	Monkey m1;
	m1.Display();
	m1.Climb();

	Rabbit r1;
	r1.Display();
	r1.Dig();

	return 0;
}