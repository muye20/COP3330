#include <iostream>

using namespace std;

const int SIZE = 10;

int main()
{
	int num_list[SIZE]; // static memory allocation
	int *p1, *p2;

	for(int i = 0; i < SIZE; i++)
		num_list[i] = i;

	return 0;
}