#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
using namespace std;

const int MAX_ITEMS = 20;
const string NONE = "N/A";
const string FILE_NAME = "Inventory.txt";

// Info object for each individual merchandise
class Info{
public:
	Info();
	void Show() const; 
	double GetTotal() const;
	string GetItem() const;
	string GetCategory() const;
	void Set(string i, string u, string c, int q, double p);

private:
	string item;
	string unit;
	string category;
	int quantity;
	double price;
}; 

class Farm{ 
public:
	Farm();
	~Farm(); // destructor
	Info *GetMerchandiseAddr() const;
	void Summary() const;
	double AllTotal() const;
	bool Search(const string target, const char field) const;
	bool LoadInfo();

private:
	Info *merchandise; // Info pointer 
	void PrintHeader() const;
};
