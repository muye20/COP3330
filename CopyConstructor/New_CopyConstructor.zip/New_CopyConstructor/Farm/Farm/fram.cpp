#include "farm.h"

Info::Info()
{
	Set(NONE, NONE, NONE, 0, 0);
}

void Info::Set(string i, string u, string c, int q, double p)
{
	item = i; 
	unit = u;
	category = c;
	quantity = q;
	price = p;
}

double Info::GetTotal() const
{
	return price * quantity;
}


string Info::GetItem() const
{
	return item;
}

string Info::GetCategory() const
{
	return category;
}

void Info::Show() const
{
	cout << left;
	cout << setw(10) << item << setw(10) << price
		<< setw(10) << unit << setw(10) << category 
		<< setw(10) << quantity << setw(10) << GetTotal()
		<< endl;
	cout << right;
}

Farm::Farm()
{
	// new => dynamic memory allocation
	// create an array of Info object
	// now, merchandise is pointing at this array
	merchandise = new Info [MAX_ITEMS];
}

Farm::~Farm()
{
	// de-allocate the memory merchandise is pointing at
	delete [] merchandise;
	cout << "~Farm() executed" << endl;
}

Info *Farm::GetMerchandiseAddr() const
{
	return merchandise;
}


bool Farm::LoadInfo()
{
	ifstream InFile;
	bool ret;

	string r_i, r_u, r_c;
	double r_p;
	int r_q;

	InFile.open(FILE_NAME.c_str(), ios::in);
	ret = false;
	
	if(InFile)
	{
		for(int i = 0; i < MAX_ITEMS; i++)
		{
			InFile >> r_i >> r_p >> r_u >> r_q >> r_c;
			// set the ith merchandise
			merchandise[i].Set(r_i, r_u, r_c, r_q, r_p);
		}
		InFile.clear();
		InFile.close();
		ret = true;
	}

	return ret; 
}

double Farm::AllTotal() const
{
	double sum = 0;
	for(int i = 0; i < MAX_ITEMS; i++)
	{
		// Get the ith merchandise's total and accumulate to sum
		sum = sum + merchandise[i].GetTotal();
	}
	return sum;
}

void Farm::PrintHeader() const
{
	cout << left;
	cout << setw(10) << "Item" << setw(10) << "Price"
		<< setw(10) << "Unit" << setw(10) << "Category" 
		<< setw(10) << "Quantity" << setw(10) << "Total"
		<< endl;
	cout << right;	
}

void Farm::Summary() const
{
	PrintHeader();
	for(int i = 0; i < MAX_ITEMS; i++)
	{
		// Shows the ith merchandise
		merchandise[i].Show();
	}
	cout << setw(56) << AllTotal() << endl;
}

bool Farm::Search(const string target, const char field) const
{
	return false;
}