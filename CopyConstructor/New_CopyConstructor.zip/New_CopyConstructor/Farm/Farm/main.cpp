#include "farm.h"

void Fun1(Farm f); // call by value
void Fun2(const Farm &f); // call by reference

int main()
{
	Farm f1, f2;
	
	if(f1.LoadInfo())
	{
		Info *tmp1;
		Info *tmp2;
		
	}
	else
		cout << "Fail to load info " << endl;

	cout << "Before return 0" << endl;
	return 0;
}

void Fun1(Farm f)
{
	cout << "Fun1 is called (call by value)" << endl;
}

void Fun2(const Farm &f)
{
	cout << "Fun2 is called (call by reference)" << endl;
}